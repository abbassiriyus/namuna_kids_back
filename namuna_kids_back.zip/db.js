const { Pool } = require('pg');

// PostgreSQL bazasiga ulanish sozlamalari
const pool = new Pool({
  user: 'postgres',         // ➤ PostgreSQL useringiz
  host: 'localhost',        // ➤ Server manzili
  database: 'bogcha',       // ➤ Bazangiz nomi
  password: 'yourpassword', // ➤ Parol (o'zgartiring)
  port: 5432                // ➤ Default port
});

module.exports = pool;
